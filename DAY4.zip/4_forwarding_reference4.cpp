int main()
{
	int n = 10;

	auto a1 = n;
	auto a2 = 10;

	auto& a3 = n;
	auto& a4 = 10;

	const auto& a5 = n;
	const auto& a6 = 10;

	auto&& a7 = n;
	auto&& a8 = 10;
}