#include <vector>
#include <iostream>

template<typename T> // allocator ����
class vector
{
	T* buff;
public:
	vector(std::size_t sz, T value)
	{
		buff = new T[sz];
	}
	T& operator[](int idx) { return buff[idx]; }
};

int main()
{
	std::vector<int>  v1(10, 0);
	std::vector<bool> v2(10, 0);

	
}