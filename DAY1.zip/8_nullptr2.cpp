// 8_nullptr2
#include <iostream>

// �� nullptr�� ������� ?
void foo(int*) { std::cout << "foo" << std::endl; }

template<typename F, typename T>
void forward_argument(F f, T arg)
{
	f(arg);
}
int main()
{
	foo(0);

	int n = 0;
	foo(n); // ?
}







