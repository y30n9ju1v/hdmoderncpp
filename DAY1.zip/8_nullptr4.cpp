#include <iostream>

// nullptr �� ����

void f1(int* p) {}
void f2(char* p) {}

int main()
{
	f1(mynullptr);
	f2(mynullptr);
}
