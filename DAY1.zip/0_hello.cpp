#include <iostream>

int main()
{
	std::cout << "hello, modern C++" << std::endl;

	int n1 = 10;
	auto n2 = 10;

	decltype(n2) n3;
}