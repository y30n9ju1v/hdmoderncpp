// 9_FOLD - 237 page

#include <iostream>


template<typename ... Types> 
int Sum(Types ... args)
{
	return s;
}
int main()
{
	int n = Sum(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

	std::cout << n << std::endl;
}



